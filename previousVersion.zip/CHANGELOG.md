
## 0.1.1 [06-18-2024]

* change to run pipeline

See merge request itentialopensource/adapters/adapter-nokia_nsp_network_management!1

---

